from flask import Flask, render_template, Response
import cv2
import time
import torch
from torchvision.transforms import transforms
import pygame
from flask import jsonify
import mediapipe as mp

app = Flask(__name__)


# Initialize pygame mixer for playing sounds
pygame.mixer.init()
# Initialize MediaPipe Hands model
# mp_hands = mp.solutions.hands.Hands(static_image_mode=False, max_num_hands=1)
mp_hands = mp.solutions.hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5)


# Define the transformations for preprocessing
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Using device:", device)

# Load the PyTorch model and map it to CPU
model = torch.load("quantum.pth", map_location=torch.device('cpu'))
model.eval()

# Define the class labels and corresponding Nepali labels
labels = ["Dhanyabaad", "Ghar","Ma", "Namaskaar"]
# labels = ["आज", "धन्यबाद", "घर", "जान्छु", "म", "नमस्कार"]

# Corresponding .wav files for each label
# label_sounds = ["static/audio/Aaja.wav", "static/audio/Dhanyabaad.wav", "static/audio/Ghar.wav", "static/audio/Jaanchu.wav", "static/audio/Ma.wav", "static/audio/Namaskaar.wav"]
label_sounds = ["static/audio/Dhanyabaad.wav", "static/audio/Ghar.wav","static/audio/Ma.wav", "static/audio/Namaskaar.wav"]


gesture_delay = 4 # Delay in sconds between predictions
countdown_time = 4
last_prediction_time = 0
sentence = ""  # To store the current sentence
completed_sentences = [] # To store completed sentence
prediction_labels ='' # To store predicted label
confidence ='' # To store confidence percent

last_detected_gesture = None

current_prediction = {'label': '', 'confidence': '', 'sentence': '', 'completed_sentences': ''}

detection_enabled = False

def generate_frames():
    global last_prediction_time, sentence, current_prediction, completed_sentences, prediction_labels, confidence, last_detected_gesture

    cap = cv2.VideoCapture(0)
    cap.set(3, 1280)
    cap.set(4, 720)

    # Define the coordinates of the ROI (you may need to adjust these for your specific use case)
    x, y, w, h = 250, 200, 800, 500

    while True:
        success, frame = cap.read()

        # Check if the frame was successfully captured
        if not success:
            print("Failed to capture frame from the camera.")
            break

        imgOutput = frame.copy()

        # Draw the ROI on the output image
        cv2.rectangle(imgOutput, (x, y), (x+w, y+h), (0, 255, 0), 2)

        remaining_time = int(countdown_time - (time.time() - last_prediction_time))
        if remaining_time > 0:
            cv2.putText(imgOutput, str(remaining_time), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)


        img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = mp_hands.process(image=img_rgb)

        if detection_enabled:
            if results.multi_hand_landmarks and len(results.multi_hand_landmarks) > 0:
                # Apply the ROI to the frame
                roi = frame[y:y+h, x:x+w]

                # Preprocess the image
                roi = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
                roi: torch.Tensor = transform(roi)
                roi = roi.unsqueeze(0).to(device)

                # Perform prediction
                with torch.inference_mode():
                    output = model(roi)
                    _, prediction_index = torch.max(output, 1)
                    prediction_labels = labels[prediction_index.item()]
                    confidence = round(torch.softmax(output, 1)[0][prediction_index.item()].item() * 100, 2)

                # if last_detected_gesture != prediction_labels:
                    # Update the last detected gesture
                # last_detected_gesture = prediction_labels
               
                    # Only update the prediction if the delay has passed
                # if time.time() - last_prediction_time >= gesture_delay:
                if (time.time() - last_prediction_time >= gesture_delay) and (prediction_labels != last_detected_gesture):
                    
                    last_detected_gesture = prediction_labels
                    # Update the last prediction time
                    last_prediction_time = time.time()

                    # Append to the current sentence
                    sentence += prediction_labels + " "

                    confidence = confidence

                    # Play the corresponding sound
                    pygame.mixer.Sound(label_sounds[prediction_index.item()]).play()
            else:
                last_detected_gesture = None
                if sentence:
                    completed_sentences.append(sentence)
                    # current_prediction['completed_sentences'] = completed_sentences.copy() + '\n'
                    sentence = ""

                if len(completed_sentences) >= 4:
                    completed_sentences = completed_sentences[-4:]

            ret, buffer = cv2.imencode('.jpg', imgOutput)
            frame = buffer.tobytes()
        else:
            ret, buffer = cv2.imencode('.jpg', frame)  # No detection, just encoding the original frame
            frame = buffer.tobytes()

        yield (b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/start')
def start():
    global detection_enabled
    detection_enabled = True
    return jsonify(success=True)

@app.route('/stop')
def stop():
    global detection_enabled
    detection_enabled = False
    return jsonify(success=True)

@app.route('/clear')
def clear():
    global completed_sentences
    completed_sentences = ""  # Clear the sentence variable
    return jsonify(success=True)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/view')
def view():
    return render_template('view.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/get_data')
def get_data():
    global sentence, completed_sentences
    last_prediction = sentence.split(" ")[-1] if sentence else None
    return jsonify(current=sentence, completed=completed_sentences, last_prediction=last_prediction)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == "__main__":
    app.run()


